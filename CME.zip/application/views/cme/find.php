        <div class="cus_search">
             <div class="form">
                
                <?php echo form_open('view/detail');?>
                    <label>Customer ID :</label>
                    <input type="text" name="fcid" placeholder="Customer ID" /> <br/><br/>
                    <input type="submit" name="submit" value="Search" /> 
                </form>
                <br/>
                
            </div>
            </div>
           