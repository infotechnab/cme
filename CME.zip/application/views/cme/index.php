      <?php 
     
            $cid='0';
            foreach ($query as $data)
            {
                $cid = $data->c_id;
            }   
                   
             $cid = $cid+1;
?>
            <div class="cme">   <p id="sucessmsg">
  <?php echo validation_errors();?>
            
         <?php  if(isset($error))
         {echo $error;} ?>
    </p></div> 
           
        <div class="cus_detail">
            <h2>Customer Entry </h2>
            <hr/>
            <div class="form">  
            <?php echo form_open_multipart('view/addcustomerdetail'); ?>
                
                <table >
                    <tr>
                        <td > <b> Customer ID </b>   </td>
                    </tr>
                    <tr>
                        <td colspan="2" > <input class="intext"  type="text" name="cid" value="<?php echo $cid; ?>" readonly /> </td>
                    </tr>
                    <tr>
                         <td> <b>Title </b> </td>
                    </tr>
                    <tr>
                       
                        <td><input type="radio" name="title" value="Mr." /> <b> Mr.</b> &nbsp; <input type="radio" name="title" value="Mrs." /><b> Mrs.</b> &nbsp; <input type="radio" name="title" value="Miss." /><b> Miss.</b> &nbsp; <input type="radio" name="title" value="Ms." /><b> Ms.</b></td>
                        
                       
                    </tr>
                    <tr>
                         <td> <b> Name </b>  </td>
                    </tr>
                          <tr>
                         <td> <input class="intexth"   type="text" name="fname" placeholder="first Name" /> </td>
                         <td> <input class="intexth"  type="text" name="lname" placeholder="last Name" /> </td>
                    </tr>
                    <tr>
                        <td> <b>Gender </b></td>
                    </tr>
                    <tr>
                        <td><input type="radio" name="sex" value="male" /> <b> Male</b></td>
                        <td><input type="radio" name="sex" value="female" /><b> Female</b></td>
                        <td><input type="radio" name="sex" value="other" /><b> Other</b></td>
                    </tr>
                    <tr>
                       <td> <b> Date Of Birth </b></td>
                    </tr>
                    <tr>
                        <td colspan="2"><input class="intextd"  type="text" name="dobyear" placeholder="year" />
                            <select class="intextd" name="dobmonth">
                                <option>Month</option>
                                <option value="1">January</option>
                                <option value="2">February</option>
                                <option value="3">March</option>
                                <option value="4">April</option>
                                <option value="5">May</option>
                                <option value="6">June</option>
                                <option value="7">July</option>
                                <option value="8">August</option>
                                <option value="9">September</option>
                                <option value="10">October</option>
                                <option value="11">November</option>
                                <option value="12">December</option>
                            </select>
                            <input class="intextd" type="text" name="dobday" placeholder="day" /> </td>
                    </tr>
                    
                    <tr>
                           <td> <b>Address </b> </td>
                    </tr>
                    <tr>
                            <td colspan="2"> <input class="intext"  type="text" name="address" placeholder="adderss" /> </td>
                    </tr>
                    <tr>                         
                             <td> <input class="intexth"   type="text" name="vdc" placeholder="vdc"/> </td>
                             <td> <input class="intexth"  type="text" name="tole" placeholder="tole"/> </td>
                    </tr>
                    
                   <tr> 
                              <td> <input class="intexth" type="text" name="distric" placeholder="Distric"/> </td>
                               <td> <input class="intexth" type="text" name="zone" placeholder="Zone" /> </td>
                    </tr>
                   
                    <tr>
                              
                              
                                <td> <b>Country </b>  </td>
                    </tr>
                    <tr>
                               <td> <select name="country">
                <option value="Nepal"> Nepal </option>
                <option value="India"> India </option>
            </select> </td>
                    </tr>
                     <tr>
                                 <td> <b> Contact Number (98********) </b> </td>
                     </tr>
                     <tr>
                                 <td><input class="intexth" type="text" name="contactpersonal" placeholder="personal" /> </td>
                                 <td><input class="intexth" type="text" name="contacthome" placeholder="home" /> </td>
                                 
                    </tr>
                    <tr>
                                  <td> <b> Email <b> </td>
                    </tr>
                    <tr>
                                 <td colspan="2"> <input class="intext" type="email" name="email"  placeholder="Email ID" /> </td>
                </tr>
                <tr>
                                   <td> <b>Customer Image </b> </td> 
                                   <td> <input type="file" name="customerfile" /> </td>
                    </tr>
                    
                </table>
              
            <div class="cidentity"> 
            <label id="clpid"> <b > Customer Identity </b></label> <hr/> 
            <table>
                <tr>
                    <th>Identity Type</th>
                    <th>Identity Number</th>
                    <th>Issue Date</th>
                    <th>Issue Place</th>
                  <!--  <th>Expire Date</th> -->
                    <th>Select Image</th>
                    
                </tr>
                <tr>
                    <td>Ctitzenship</td>
                   <?php $mydate=getdate(date("U"));?> 
                    <td><input type="hidden" name="citizenship" value="citizenship" /><input type="text" name="ctznid" /></td>
                    <td><input type="text" class="issued" name="ctznyear" placeholder="year" /> 
                        <select class="issued" name="ctznmonth">
                                <option>Month</option>
                                <option value="1">January</option>
                                <option value="2">February</option>
                                <option value="3">March</option>
                                <option value="4">April</option>
                                <option value="5">May</option>
                                <option value="6">June</option>
                                <option value="7">July</option>
                                <option value="8">August</option>
                                <option value="9">September</option>
                                <option value="10">October</option>
                                <option value="11">November</option>
                                <option value="12">December</option>
                            </select>
                        <input type="text" class="issued" name="ctznday" placeholder="day" /></td>
                    <td><input type="text" name="ctznplace" /></td>
                  <!--  <td><input type="text" name="ctznexpire" value="<?php //echo "  $mydate[year]- $mydate[mon]- $mydate[mday]"; ?>" /></td> -->
                    <td><input type="file" name="ctznfile" /></td>
                </tr>
                <tr>
                    <td>License</td>
                    <td><input type="hidden" name="license" value="license" /><input type="text" name="lid" /></td>
                    
                    <td><input type="text" class="issued" name="lyear" placeholder="year" /> 
                        <select class="issued" name="lmonth">
                                <option>Month</option>
                                <option value="1">January</option>
                                <option value="2">February</option>
                                <option value="3">March</option>
                                <option value="4">April</option>
                                <option value="5">May</option>
                                <option value="6">June</option>
                                <option value="7">July</option>
                                <option value="8">August</option>
                                <option value="9">September</option>
                                <option value="10">October</option>
                                <option value="11">November</option>
                                <option value="12">December</option>
                            </select>
                        <input type="text" class="issued" name="lday" placeholder="day" /></td>
                    
                    <td><input type="text" name="lplace" /></td>
                    <!--<td><input type="text" name="lexpire" value="<?php //echo "  $mydate[year]- $mydate[mon]- $mydate[mday]"; ?>"/></td> -->
                    <td><input type="file" name="lfile" /></td>
                </tr>
                 <tr>
                    <td>Passport</td>
                    <td><input type="hidden" name="passport" value="passport" /><input type="text" name="pid" /></td>
                    <td><input type="text" class="issued" name="pyear" placeholder="year" /> 
                        <select class="issued" name="pmonth">
                                <option>Month</option>
                                <option value="1">January</option>
                                <option value="2">February</option>
                                <option value="3">March</option>
                                <option value="4">April</option>
                                <option value="5">May</option>
                                <option value="6">June</option>
                                <option value="7">July</option>
                                <option value="8">August</option>
                                <option value="9">September</option>
                                <option value="10">October</option>
                                <option value="11">November</option>
                                <option value="12">December</option>
                            </select>
                        <input type="text" class="issued" name="pday" placeholder="day" /></td>
                    
                    <td><input type="text" name="pplace" /></td>
                    <!--<td><input type="text" name="pexpire" value="<?php //echo "  $mydate[year]- $mydate[mon]- $mydate[mday]"; ?>" /></td> -->
                    <td><input type="file" name="pfile" /></td>
                </tr>
                 <tr>
                    <td>Other</td>
                    <td><input type="hidden" name="other" value="other" /><input type="text" name="oid" /></td>
                    
                    <td><input type="text" class="issued" name="oyear" placeholder="year" /> 
                        <select class="issued" name="omonth">
                                <option>Month</option>
                                <option value="1">January</option>
                                <option value="2">February</option>
                                <option value="3">March</option>
                                <option value="4">April</option>
                                <option value="5">May</option>
                                <option value="6">June</option>
                                <option value="7">July</option>
                                <option value="8">August</option>
                                <option value="9">September</option>
                                <option value="10">October</option>
                                <option value="11">November</option>
                                <option value="12">December</option>
                            </select>
                        <input type="text" class="issued" name="oday" placeholder="day" /></td>
                    <td><input type="text" name="oplace" /></td>
                  <!--  <td><input type="text" name="oexpire" value="<?php //echo "  $mydate[year]- $mydate[mon]- $mydate[mday]"; ?>" /></td> -->
                    <td><input type="file" name="ofile" /></td>
                </tr>
            </table>
            </div>
           <input type="submit" name="submit" value="Add Details" />
           <?php echo form_close(); ?>
            </div>
        </div>            