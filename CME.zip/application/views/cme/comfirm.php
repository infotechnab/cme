<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Chitwan Money Express</title>
<link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>content/styles/cme.css" />
</head>
    <style>
        @media print{
            #pageprint{
                display: none;
            }
            
        }
    </style>

<body class="printview">
     <?php 
        $this->session->userdata('username');
       $user_id = $this->session->userdata('id');
       $bid = $this->session->userdata('bid');
       //$branch = $this->session->userdata('branch');
      ?>
     <?php 
                 foreach ($query as $data)
                 {
                     $refcode = $data->ref_number;
                     $rname = $data->r_name;
                     $address = $data->address;
                     $phone = $data->contact;
                     $sname = $data->s_name;
                     $country = $data->country;
                     $amount = $data->amount;
                     $idtype = $data->d_type;
                     $idnum = $data->d_number;
                     $authcode = $data->auth_code;
                     $agent = $data->agent;
                     $cdate = $data->date;
                     $idplace = $data->d_place;
                     $iddate = $data->d_date;
                     $idexpire = $data->d_expire;
                     $income = $data->source;
                     $relation = $data->relation;
                     $stitle = $data->s_title;
                     $rtitle = $data->r_title;
                     $city = $data->city;
                 }
                 //$date = date('20y-m-d ',intval($date));
                 //$date = strtotime($date);
                 
               // print_r($cdate);
                 
                //$date1 = new DateTime();
                //$date1->setDate(2013, 12,12);
                
                 $agentimg = $this->dbmodel->get_agentimg($agent);
                 $branch = $this->dbmodel->get_branch($bid);
                
                  //$time_stamp=time(); //gives timestamp
//$date_format=date("m:d:y",$time_stamp); // formats timestamp in mm:dd:yy 
 
                // die($date);
                foreach ($branch as $data)
                {
                    $bname = $data->b_name;
                }
                foreach ($agentimg as $data)
                {
                    $img = $data->image;
                }
         ?> 
    <div id="officecopy" style="float: left; font-size: 11px; margin-right: 10px;">
<table  border="1" cellpadding="5" style="border-collapse:collapse; width: 480px;  ">
  <tr>
      <th colspan="4" scope="col"><img src="<?php echo base_url(); ?>content/images/sagarmatha.png" width="300" height="68" /><img src="<?php echo base_url(); ?>agentimg/<?php echo $img; ?>" width="150" height="59" /></th>
  </tr>
  <tr>
    <td colspan="4"> <strong><?php echo $bname; ?></strong></td>
  </tr>
  <tr>
    <td width="247">Reference/Code Number</td>
    <td width="261"><?php echo $refcode; ?></td>
    <td>Authorization Code If any</td>
    <td width="142"><?php echo $authcode; ?></td>
  </tr>
  <tr>
    <td colspan="2"><strong>Receiver's Info</strong></td>
    <td colspan="2" rowspan="8"><strong>office Stamp</strong></td>
  </tr>
  <tr>
    <td>Title</td>
    <td><?php echo $rtitle; ?></td>
  </tr> 
  <tr>
    <td>Name:</td>
    <td><?php echo $rname; ?></td>
  </tr>
  <tr>
    <td>Address:</td>
    <td><?php echo $address; ?></td>
  </tr>
  <tr>
    <td>Town / City :</td>
    <td><?php echo $city; ?></td>
  </tr>
  <tr>
    <td>Country:</td>
    <td>Nepal</td>
  </tr>
  <tr>
    <td>Relationship with Sender:</td>
    <td><?php echo $relation; ?></td>
  </tr>
  <tr>
    <td>Contact Number:</td>
    <td><?php echo $phone; ?></td>
  </tr>
  <tr>
    <td colspan="2"><strong>Sender's Info</strong></td>
    <td colspan="2"><strong>Receiver's ID Detail</strong></td>
  </tr>
  <tr>
    <td>Title:</td>
    <td><?php echo $stitle; ?></td>
    <td><strong>Type: </strong></td>
    <td><?php echo $idtype; ?></td>
  </tr>
  <tr>
    <td>Name: </td>
    <td><?php echo $sname; ?></td>
    <td><strong>ID Number: </strong></td>
    <td><?php echo $idnum; ?></td>
  </tr>
  <tr>
    <td>Country:</td>
    <td><?php echo $country; ?></td>
    <td><strong>Issued Place:</strong></td>
    <td><?php echo $idplace; ?></td>
  </tr>
  <tr>
    <td>Income Source:</td>
    <td><?php echo $income; ?></td>
    <td><strong>Issued Date: </strong></td>
    <td><?php echo $iddate; ?></td>
  </tr>
  <tr>
    <td><strong>Amount: </strong></td>
    <td><?php echo $amount; ?></td>
    <td><strong>Expired Date: </strong></td>
    <td><?php echo $idexpire; ?></td>
  </tr>
  <tr>
    <td colspan="4"><strong>Transaction Disclaimer</strong></td>
  </tr>
  <tr>
    <td colspan="4"><p>I hereby declare that the information furnished above is true and   correct and guarantee to indemnify the <b> <?php echo $agent; ?> </b> in the event of the third party claim or any loss   arising out of the above transaction.</p>

    <p>&nbsp;</p>
    <p>&nbsp;</p>
        <div class="recive_sign">
                    <div class="sign"> <hr/> <br/> Receiver Signature </div>
                    <div class="sign" style="margin-top: -13px;"> <?php echo date('Y-M-d',  strtotime($cdate)); ?> <hr/> <br/> Date </div>
                      <div class="sign"> <hr/> <br/> Prepared By </div>
                       <div class="sign"> <hr/> <br/> Check and Approved by</div>
                </div>
    </td>
       
  </tr>
  <tr>
    <td colspan="4"><strong>web: www.cmeremit.com.np Email: info@cmeremit.com Facebook: www.facebook.com/cmeremit</strong></td>
  </tr>
</table>
<hr />

<p style="text-align: center;">Official Copy</p>
    </div>
    
    <a id="pageprint" href="#" onclick="window.print(); return false;"> print </a>
    
    
    <div id="customercopy" style="float:right; font-size: 11px;">
    <table  border="1" cellpadding="5" style="border-collapse:collapse; width: 480px;">
  <tr>
      <th colspan="4" scope="col"><img src="<?php echo base_url(); ?>content/images/sagarmatha.png" width="300" height="68" /><img src="<?php echo base_url(); ?>agentimg/<?php echo $img; ?>" width="150" height="59" /></th>
  </tr>
  <tr>
    <td colspan="4"> <strong><?php echo $bname; ?></strong></td>
  </tr>
  <tr>
    <td width="247">Reference/Code Number</td>
    <td width="261"><?php echo $refcode; ?></td>
    <td>Authorization Code If any</td>
    <td width="142"><?php echo $authcode; ?></td>
  </tr>
  <tr>
    <td colspan="2"><strong>Receiver's Info</strong></td>
    <td colspan="2" rowspan="8"><strong>office Stamp</strong></td>
  </tr>
  <tr>
    <td>Title</td>
    <td><?php echo $rtitle; ?></td>
  </tr> 
  <tr>
    <td>Name:</td>
    <td><?php echo $rname; ?></td>
  </tr>
  <tr>
    <td>Address:</td>
    <td><?php echo $address; ?></td>
  </tr>
  <tr>
    <td>Town / City :</td>
    <td><?php echo $city; ?></td>
  </tr>
  <tr>
    <td>Country:</td>
    <td>Nepal</td>
  </tr>
  <tr>
    <td>Relationship with Sender:</td>
    <td><?php echo $relation; ?></td>
  </tr>
  <tr>
    <td>Contact Number:</td>
    <td><?php echo $phone; ?></td>
  </tr>
  <tr>
    <td colspan="2"><strong>Sender's Info</strong></td>
    <td colspan="2"><strong>Receiver's ID Detail</strong></td>
  </tr>
  <tr>
    <td>Title:</td>
    <td><?php echo $stitle; ?></td>
    <td><strong>Type: </strong></td>
    <td><?php echo $idtype; ?></td>
  </tr>
  <tr>
    <td>Name: </td>
    <td><?php echo $sname; ?></td>
    <td><strong>ID Number: </strong></td>
    <td><?php echo $idnum; ?></td>
  </tr>
  <tr>
    <td>Country:</td>
    <td><?php echo $country; ?></td>
    <td><strong>Issued Place:</strong></td>
    <td><?php echo $idplace; ?></td>
  </tr>
  <tr>
    <td>Income Source:</td>
    <td><?php echo $income; ?></td>
    <td><strong>Issued Date: </strong></td>
    <td><?php echo $iddate; ?></td>
  </tr>
  <tr>
    <td><strong>Amount: </strong></td>
    <td><?php echo $amount; ?></td>
    <td><strong>Expired Date: </strong></td>
    <td><?php echo $idexpire; ?></td>
  </tr>
  <tr>
    <td colspan="4"><strong>Transaction Disclaimer</strong></td>
  </tr>
  <tr>
    <td colspan="4"><p>I hereby declare that the information furnished above is true and   correct and guarantee to indemnify the <b> <?php echo $agent; ?> </b> in the event of the third party claim or any loss   arising out of the above transaction.</p>

    <p>&nbsp;</p>
    <p>&nbsp;</p>
        <div class="recive_sign">
                    <div class="sign"> <hr/> <br/> Receiver Signature </div>
                    <div class="sign" style="margin-top: -13px;"> <?php echo date('Y-M-d',  strtotime($cdate)); ?> <hr/> <br/> Date </div>
                      <div class="sign"> <hr/> <br/> Prepared By </div>
                       <div class="sign"> <hr/> <br/> Check and Approved by</div>
                </div>
    </td>
        
        
       
  </tr>
  <tr>
    <td colspan="4"><strong>web: www.cmeremit.com.np Email: info@cmeremit.com Facebook: www.facebook.com/cmeremit</strong></td>
  </tr>
</table>
        
<hr />    
<p style="text-align: center;">Customer Copy</p>
        
    </div>
</body>
</html>