<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class view extends CI_Controller {

     function __construct() {
        parent::__construct();
        $this->load->model('dbmodel');
        $this->load->helper('url');
        $this->load->helper(array('form', 'url'));
        $this->load->library("pagination");
    }
	
         public function index() {
             
        if ($this->session->userdata('logged_in')) {
            $data['username'] = Array($this->session->userdata('logged_in'));
            $data['query'] = $this->dbmodel->role();
            $this->load->view('cme/header');
            $this->load->view('cme/find',$data);
            $this->load->view('cme/footer');
            
        } else {
            redirect('login', 'refresh');
        }
    }
    
     public function addcustomerdetail() {
             
        if ($this->session->userdata('logged_in')) {
            
             $config['upload_path'] = './custmr_detail_image/';
            $config['allowed_types'] = 'gif|jpg|png';
            $config['max_size'] = '500';
            $config['max_width'] = '1024';
            $config['max_height'] = '724';
            $this->load->library('upload', $config);
            
            //$this->load->view('cme/find');
             //$this->load->helper('form');
            
            $this->load->library(array('form_validation', 'session'));
            //set validation rules
            $this->form_validation->set_rules('fname', 'First Name', 'required|xss_clean|max_length[200]');
            $this->form_validation->set_rules('lname', 'Last Name', 'required|xss_clean');
            $this->form_validation->set_rules('address', 'Address', 'required|xss_clean');
            $this->form_validation->set_rules('zone', 'Zone', 'required|xss_clean');
            $this->form_validation->set_rules('sex', 'Gender', 'required|xss_clean');
            
            // validation true
            
             if (($this->form_validation->run() == TRUE))
            {
             if ($_FILES && $_FILES['customerfile']['name'] !== "")
             {
                 if (!$this->upload->do_upload('customerfile'))
                 {
                  $data = array('error' => $this->upload->display_errors('customerfile'));
                  $data['query'] = $this->dbmodel->customer();
                  $this->load->view('cme/header');
                  $this->load->view('cme/index', $data);
                  $this->load->view('cme/footer');
                 }
                 else
                 {
                $data = array('upload_data' => $this->upload->data('customerfile'));
                //============= customer detail==========
                $cusimage = $data['upload_data']['file_name'];

                $cid = $this->input->post('cid');
                $fname = $this->input->post('fname');
                $lname = $this->input->post('lname');
                $address = $this->input->post('address');
                $distric = $this->input->post('distric');
                $vdc = $this->input->post('vdc');
                $tole = $this->input->post('tole');
                $zone = $this->input->post('zone');
                $country = $this->input->post('country');
                $email = $this->input->post('email');
                $gender = $this->input->post('sex');
                 $year = $this->input->post('dobyear');
                $month = $this->input->post('dobmonth');
                $day = $this->input->post('dobday');
                $dob = $year."-".$month."-".$day;
               // $dob = date("y-m-d");
                $conpersonal = $this->input->post('contactpersonal');
                $conhome = $this->input->post('contacthome');
                $title = $this->input->post('title');
                
                //===========customer id detail ================//
                //
                //=======for ctzn =====//
                          
            if ($_FILES && $_FILES['ctznfile']['name'] !== "")
             {
                 if (!$this->upload->do_upload('ctznfile'))
                 {
                  $data = array('error' => $this->upload->display_errors('ctznfile'));
                  $data['query'] = $this->dbmodel->customer();
                  $this->load->view('cme/header');
                  $this->load->view('cme/index', $data);
                  $this->load->view('cme/footer');
                 }
                 else
                 {
                     $data = array('upload_data' => $this->upload->data('ctznfile'));
               
                $ctznimage = $data['upload_data']['file_name'];
            
                $typectzn = $this->input->post('citizenship');
                $ctznid = $this->input->post('ctznid');
                $ctznplace = $this->input->post('ctznplace');
                $year = $this->input->post('ctznyear');
                $month = $this->input->post('ctznmonth');
                $day = $this->input->post('ctznday');
                $ctzndate = $year."-".$month."-".$day;
               
                 }
                 }
             else
             {
                 
                $ctznimage = " ";
                $typectzn = $this->input->post('citizenship');
                $ctznid = $this->input->post('ctznid');
                $ctznplace = $this->input->post('ctznplace');
                $year = $this->input->post('ctznyear');
                $month = $this->input->post('ctznmonth');
                $day = $this->input->post('ctznday');
                $ctzndate = $year."-".$month."-".$day;
             }
                
                
                //=====for license =======//
             
              if ($_FILES && $_FILES['lfile']['name'] !== "")
             {
                 if (!$this->upload->do_upload('lfile'))
                 {
                  $data = array('error' => $this->upload->display_errors('lfile'));
                  $data['query'] = $this->dbmodel->customer();
                  $this->load->view('cme/header');
                  $this->load->view('cme/index', $data);
                  $this->load->view('cme/footer');
                 }
                 else
                 {
                     $data = array('upload_data' => $this->upload->data('lfile'));
               
                $limage = $data['upload_data']['file_name'];
            
                $typelicense = $this->input->post('license');
                $lid = $this->input->post('lid');
                $lplace = $this->input->post('lplace');
               $lyear = $this->input->post('lyear');
                $lmonth = $this->input->post('lmonth');
                $lday = $this->input->post('lday');
                $ldate = $lyear."-".$lmonth."-".$lday;
                
                 }
                 }
             else
             {
                 
                $limage = " ";
                $typelicense = $this->input->post('license');
                $lid = $this->input->post('lid');
                $lplace = $this->input->post('lplace');
                $lyear = $this->input->post('lyear');
                $lmonth = $this->input->post('lmonth');
                $lday = $this->input->post('lday');
                $ldate = $lyear."-".$lmonth."-".$lday;
             }            
               
                
                //========for passport ====//
                
                 if ($_FILES && $_FILES['pfile']['name'] !== "")
             {
                 if (!$this->upload->do_upload('pfile'))
                 {
                  $data = array('error' => $this->upload->display_errors('pfile'));
                  $data['query'] = $this->dbmodel->customer();
                  $this->load->view('cme/header');
                  $this->load->view('cme/index', $data);
                  $this->load->view('cme/footer');
                 }
                 else
                 {
                     $data = array('upload_data' => $this->upload->data('pfile'));
               
                $pimage = $data['upload_data']['file_name'];
            
                 $typepassport = $this->input->post('passport');
                $pid = $this->input->post('pid');
                $pplace = $this->input->post('pplace');
                $pyear = $this->input->post('pyear');
                $pmonth = $this->input->post('pmonth');
                $pday = $this->input->post('pday');
                $pdate = $pyear."-".$pmonth."-".$pday;
                
                 }
                 }
             else
             {
                 
                $pimage = " ";
                $typepassport = $this->input->post('passport');
                $pid = $this->input->post('pid');
                $pplace = $this->input->post('pplace');
                $pyear = $this->input->post('pyear');
                $pmonth = $this->input->post('pmonth');
                $pday = $this->input->post('pday');
                $pdate = $pyear."-".$pmonth."-".$pday;
             }
                      
                
                // =====for others =======//
                
                 if ($_FILES && $_FILES['ofile']['name'] !== "")
             {
                 if (!$this->upload->do_upload('ofile'))
                 {
                  $data = array('error' => $this->upload->display_errors('ofile'));
                  $data['query'] = $this->dbmodel->customer();
                  $this->load->view('cme/header');
                  $this->load->view('cme/index', $data);
                  $this->load->view('cme/footer');
                 }
                 else
                 {
                     $data = array('upload_data' => $this->upload->data('ofile'));
               
                $oimage = $data['upload_data']['file_name'];
            
                $typeother = $this->input->post('other');
                $oid = $this->input->post('oid');
                $oplace = $this->input->post('oplace');
                $oyear = $this->input->post('oyear');
                $omonth = $this->input->post('omonth');
                $oday = $this->input->post('oday');
                $odate = $oyear."-".$omonth."-".$oday;
               
                 }
                 }
             else
             {
                 
                $oimage = " ";
                 $typeother = $this->input->post('other');
                $oid = $this->input->post('oid');
                $oplace = $this->input->post('oplace');
                $oyear = $this->input->post('oyear');
                $omonth = $this->input->post('omonth');
                $oday = $this->input->post('oday');
                $odate = $oyear."-".$omonth."-".$oday;
             }
                
                $this->dbmodel->add_details($cid,$fname, $lname, $address, $distric,$vdc,$tole,$zone,$country,$email,$cusimage,$gender,$dob,$conpersonal,$conhome,$title);
                $this->dbmodel->add_id_ctzn($cid,$typectzn,$ctznid,$ctznplace,$ctzndate,$ctznimage);
                 $this->dbmodel->add_id_license($cid,$typelicense,$lid,$lplace,$ldate,$limage);
                 $this->dbmodel->add_id_passport($cid,$typepassport,$pid,$pplace,$pdate,$pimage);
                 $this->dbmodel->add_id_other($cid,$typeother,$oid,$oplace,$odate,$oimage);
                
                $this->session->set_flashdata('message', 'One Customer added sucessfully');
                redirect('view/index');

                 }
             }
             else
             {
                 //=====customer detail======//
                $cusimage = "";
                $cid = $this->input->post('cid');
                $fname = $this->input->post('fname');
                $lname = $this->input->post('lname');
                $address = $this->input->post('address');
                $distric = $this->input->post('distric');
                $vdc = $this->input->post('vdc');
                $tole = $this->input->post('tole');
                $zone = $this->input->post('zone');
                $country = $this->input->post('country');
                $email = $this->input->post('email');
                $gender = $this->input->post('sex');
                 $year = $this->input->post('dobyear');
                $month = $this->input->post('dobmonth');
                $day = $this->input->post('dobday');
                $dob = $year."-".$month."-".$day;
                
                $conpersonal = $this->input->post('contactpersonal');
                $conhome = $this->input->post('contacthome');
                $title = $this->input->post('title');
                
                 //===========customer id detail ================//
                //
                if ($_FILES && $_FILES['ctznfile']['name'] !== "")
             {
                 if (!$this->upload->do_upload('ctznfile'))
                 {
                  $data = array('error' => $this->upload->display_errors('ctznfile'));
                  $data['query'] = $this->dbmodel->customer();
                  $this->load->view('cme/header');
                  $this->load->view('cme/index', $data);
                  $this->load->view('cme/footer');
                 }
                 else
                 {
                     $data = array('upload_data' => $this->upload->data('ctznfile'));
               
                $ctznimage = $data['upload_data']['file_name'];
            
                $typectzn = $this->input->post('citizenship');
                $ctznid = $this->input->post('ctznid');
                $ctznplace = $this->input->post('ctznplace');
                $year = $this->input->post('ctznyear');
                $month = $this->input->post('ctznmonth');
                $day = $this->input->post('ctznday');
                $ctzndate = $year."-".$month."-".$day;
                 }
                 }
             else
             {
                 
                $ctznimage = " ";
                $typectzn = $this->input->post('citizenship');
                $ctznid = $this->input->post('ctznid');
                $ctznplace = $this->input->post('ctznplace');
                $year = $this->input->post('ctznyear');
                $month = $this->input->post('ctznmonth');
                $day = $this->input->post('ctznday');
                $ctzndate = $year."-".$month."-".$day;
             }
                
                //=====for license =======//
              if ($_FILES && $_FILES['lfile']['name'] !== "")
             {
                 if (!$this->upload->do_upload('lfile'))
                 {
                  $data = array('error' => $this->upload->display_errors('lfile'));
                  $data['query'] = $this->dbmodel->customer();
                  $this->load->view('cme/header');
                  $this->load->view('cme/index', $data);
                  $this->load->view('cme/footer');
                 }
                 else
                 {
                     $data = array('upload_data' => $this->upload->data('lfile'));
               
                $limage = $data['upload_data']['file_name'];
            
                $typelicense = $this->input->post('license');
                $lid = $this->input->post('lid');
                $lplace = $this->input->post('lplace');
                $lyear = $this->input->post('lyear');
                $lmonth = $this->input->post('lmonth');
                $lday = $this->input->post('lday');
                $ldate = $lyear."-".$lmonth."-".$lday;
                 }
                 }
             else
             {
                 
                $limage = " ";
                $typelicense = $this->input->post('license');
                $lid = $this->input->post('lid');
                $lplace = $this->input->post('lplace');
                $lyear = $this->input->post('lyear');
                $lmonth = $this->input->post('lmonth');
                $lday = $this->input->post('lday');
                $ldate = $lyear."-".$lmonth."-".$lday;
             }
                
                //========for passport ====//
                
                 if ($_FILES && $_FILES['pfile']['name'] !== "")
             {
                 if (!$this->upload->do_upload('pfile'))
                 {
                  $data = array('error' => $this->upload->display_errors('pfile'));
                  $data['query'] = $this->dbmodel->customer();
                  $this->load->view('cme/header');
                  $this->load->view('cme/index', $data);
                  $this->load->view('cme/footer');
                 }
                 else
                 {
                     $data = array('upload_data' => $this->upload->data('pfile'));
               
                $pimage = $data['upload_data']['file_name'];
            
                $typepassport = $this->input->post('passport');
                $pid = $this->input->post('pid');
                $pplace = $this->input->post('pplace');
                $pyear = $this->input->post('pyear');
                $pmonth = $this->input->post('pmonth');
                $pday = $this->input->post('pday');
                $pdate = $pyear."-".$pmonth."-".$pday;
                 }
                 }
             else
             {
                 
                $pimage = " ";
                $typepassport = $this->input->post('passport');
                $pid = $this->input->post('pid');
                $pplace = $this->input->post('pplace');
                $pyear = $this->input->post('pyear');
                $pmonth = $this->input->post('pmonth');
                $pday = $this->input->post('pday');
                $pdate = $pyear."-".$pmonth."-".$pday;
             }
                
                // =====for others =======//
                
                 if ($_FILES && $_FILES['ofile']['name'] !== "")
             {
                 if (!$this->upload->do_upload('ofile'))
                 {
                  $data = array('error' => $this->upload->display_errors('ofile'));
                  $data['query'] = $this->dbmodel->customer();
                  $this->load->view('cme/header');
                  $this->load->view('cme/index', $data);
                  $this->load->view('cme/footer');
                 }
                 else
                 {
                     $data = array('upload_data' => $this->upload->data('ofile'));
               
                $oimage = $data['upload_data']['file_name'];
            
                $typeother = $this->input->post('other');
                $oid = $this->input->post('oid');
                $oplace = $this->input->post('oplace');
                $oyear = $this->input->post('oyear');
                $omonth = $this->input->post('omonth');
                $oday = $this->input->post('oday');
                $odate = $oyear."-".$omonth."-".$oday;
                 }
                 }
             else
             {
                 
                $oimage = " ";
                $typeother = $this->input->post('other');
                $oid = $this->input->post('oid');
                $oplace = $this->input->post('oplace');
                $oyear = $this->input->post('oyear');
                $omonth = $this->input->post('omonth');
                $oday = $this->input->post('oday');
                $odate = $oyear."-".$omonth."-".$oday;
             }
                $this->dbmodel->add_details($cid,$fname, $lname, $address, $distric,$vdc,$tole,$zone,$country,$email,$cusimage,$gender,$dob,$conpersonal,$conhome,$title);
                $this->dbmodel->add_id_ctzn($cid,$typectzn,$ctznid,$ctznplace,$ctzndate,$ctznimage);
                 $this->dbmodel->add_id_license($cid,$typelicense,$lid,$lplace,$ldate,$limage);
                 $this->dbmodel->add_id_passport($cid,$typepassport,$pid,$pplace,$pdate,$pimage);
                 $this->dbmodel->add_id_other($cid,$typeother,$oid,$oplace,$odate,$oimage);
               
                $this->session->set_flashdata('message', 'One Customer added sucessfully');
                redirect('view/index');

             }
            }
             else
            {
                 $data['query'] = $this->dbmodel->customer();
                 $this->load->view('cme/header');
                $this->load->view('cme/index',$data);
                $this->load->view('cme/footer');
            }          
          
        } else {
            redirect('login', 'refresh');
        }
    }
    
    public function addcustomer()
    {
         if ($this->session->userdata('logged_in')) {
           // $data['username'] = Array($this->session->userdata('logged_in'));
            $data['query'] = $this->dbmodel->customer();
            $this->load->view('cme/header');
            $this->load->view('cme/index',$data);
            $this->load->view('cme/footer');
        } else {
            redirect('login', 'refresh');
        }
    }
        
    //========= for find deteil =======//
    
     public function detail() {
             
        if ($this->session->userdata('logged_in')) {
            $data['username'] = Array($this->session->userdata('logged_in'));
            $fcid=  $this->input->post('fcid');
            $data['query'] = $this->dbmodel->customer_detail($fcid);
            $this->load->view('cme/header');
            $this->load->view('cme/detail',$data);
            $this->load->view('cme/footer');
        } else {
            redirect('login', 'refresh');
        }
    }
    
    function logout() {
        $this->session->sess_destroy();
        $this->index();
        redirect('login', 'refresh');
    }

    
    public function print_page()
    {if ($this->session->userdata('logged_in')) {
        $this->load->view('cme/print');
         } else {
            redirect('login', 'refresh');
        }
            
        
    }
   
    public function comfirm()
    {
         if ($this->session->userdata('logged_in')) {
             $data['query'] = $this->dbmodel->get_claim();
            
        $this->load->view('cme/comfirm',$data);
        
         } else {
            redirect('login', 'refresh');
        }
    }
   //===============agent =====================//
    public function agent()
    {
         if ($this->session->userdata('logged_in')&& ($this->session->userdata('username')=="ad")) {
             $this->load->view('cme/header');
        $this->load->view('cme/agent');
        $this->load->view('cme/footer');
         } else {
            redirect('login', 'refresh');
        }
       
        
    }
    
    public function addagent()
    {
        
       
         if ($this->session->userdata('logged_in')&& ($this->session->userdata('username')=="ad")) {

            $config['upload_path'] = './agentimg/';
            $config['allowed_types'] = 'gif|jpg|png';
            $config['max_size'] = '500';
            $config['max_width'] = '1024';
            $config['max_height'] = '768';

            $this->load->library('upload', $config);
           
            $this->load->library(array('form_validation', 'session'));
            
            $this->form_validation->set_rules('cmea_name', 'Name', 'required|xss_clean|max_length[200]');
            $this->form_validation->set_rules('cmea_address', 'Address', 'required|xss_clean');
             $this->form_validation->set_rules('cmea_number', 'Phone Number', 'required|xss_clean');
              $this->form_validation->set_rules('cmea_email', 'Email', 'required|xss_clean');
            
        
            if (($this->form_validation->run() == FALSE) || (!$this->upload->do_upload('agentfile'))) {
                $data['error']=$this->upload->display_errors('agentfile');
                $this->load->view('cme/header'); 
               $this->load->view('cme/agent',$data);
               $this->load->view('cme/footer');
              
            } else {
 
                //if valid
                $data = array('upload_data' => $this->upload->data('agentfile'));
                $image = $data['upload_data']['file_name'];
                $name = $this->input->post('cmea_name');
                $address = $this->input->post('cmea_address');
                $number = $this->input->post('cmea_number');
                $email = $this->input->post('cmea_email');
                $principal = $this->input->post('cmea_principal');
                
                $this->dbmodel->addagent($image,$name,$address,$number,$email,$principal);
                $this->session->set_flashdata('message', 'Agent added sucessfully');
                redirect('view/agent');
            }
           
        } else
            {

            redirect('login', 'refresh');
        }
    }
    
    public function tranzaction()
    {
         if ($this->session->userdata('logged_in')) {
            $this->load->view('cme/header');  
         $data['query']= $this->dbmodel->get_agent();
          
        $this->load->view('cme/tranzaction',$data);
        $this->load->view('cme/footer');
         } else {
            redirect('login', 'refresh');
        }
    }
        
        public function get_tran()
        {
             if ($this->session->userdata('logged_in')) {
          $this->load->view('cme/header');
          
                 $data['query']= $this->dbmodel->get_agent();
                     $fcid = $this->input->post('id');
         $data['customer'] = $this->dbmodel->customer_detail($fcid);
        
        $this->load->view('cme/get_tran',$data);
        $this->load->view('cme/footer');
         } else {
            redirect('login', 'refresh');
        }
            
        
        }
        
        public function get_agent()
        {
             if ($this->session->userdata('logged_in')&& ($this->session->userdata('username')=="ad")) {
         $data['query']= $this->dbmodel->get_agent();
         $this->load->view('cme/header');  
        $this->load->view('cme/agentlist',$data);
        $this->load->view('cme/footer');
         } else {
            redirect('login', 'refresh');
        }
        }

        


        public function userlist()
        {
            
         if ($this->session->userdata('logged_in') && ($this->session->userdata('username')=="ad")) {
            
             $data['userlist'] = $this->dbmodel->userlist();
              $this->load->view('cme/header');  
        $this->load->view('cme/userlist',$data);
        $this->load->view('cme/footer');
             
         } else {
            redirect('login', 'refresh');
        } 
            
        }

                public function user() {
         
         if ($this->session->userdata('logged_in') && ($this->session->userdata('username')=="ad")) {
             $this->load->view('cme/header');
             $data['branch']=  $this->dbmodel->branch();
          $this->load->view('cme/user',$data);
          $this->load->view('cme/footer');
         } else {
            redirect('login', 'refresh');
        }    
        
       
    }
    
    public function user_acc($abc)
    {
        die ($abc);
        
    }


    public function addtranzaction()
    {
        if ($this->session->userdata('logged_in')) {

                       
            $this->load->library(array('form_validation', 'session'));
            
            $this->form_validation->set_rules('ref_number', 'Refrence Number', 'required|xss_clean|max_length[200]');
           $this->form_validation->set_rules('s_name', 'Sender Name', 'required|xss_clean');
             $this->form_validation->set_rules('s_amount', 'Amount', 'required|xss_clean');
             $this->form_validation->set_rules('r_name', 'Recider Name', 'required|xss_clean');
              $this->form_validation->set_rules('r_add', 'Reciver Address', 'required|xss_clean');
             $this->form_validation->set_rules('r_number', 'Contact Number', 'required|xss_clean');
             $this->form_validation->set_rules('identity', 'Identity', 'required|xss_clean');
             $this->form_validation->set_rules('country', 'Country', 'required|xss_clean');
             $this->form_validation->set_rules('r_idnumber', 'ID Number', 'required|xss_clean');
              $this->form_validation->set_rules('r_issueplace', 'Issue Place', 'required|xss_clean');
             //$this->form_validation->set_rules('r_issuedate', 'Issue Date', 'required|xss_clean');
             $country = $this->input->post('country');
             $data['query']= $this->dbmodel->get_agent();
              
              
                  
        
            if (($this->form_validation->run() == FALSE) ) {
               
                $this->load->view('cme/header'); 
               $this->load->view('cme/tranzaction',$data);
               $this->load->view('cme/footer');
              
            }
           else {
 
                //if valid
                $id = $this->input->post('uid');
                $rnumber = $this->input->post('ref_number');
                $compname = $this->input->post('a_name');
                $auth = $this->input->post('auth_code');
                $sname = $this->input->post('s_name');
                $country = $this->input->post('country');
                $amount = $this->input->post('s_amount');
                $income = $this->input->post('income');
                $rname = $this->input->post('r_name');
                $raddress = $this->input->post('r_add');
                $contact = $this->input->post('r_number');
                $identity = $this->input->post('identity');
                $idnumber = $this->input->post('r_idnumber');
                $issueplace = $this->input->post('r_issueplace');
                $ryear = $this->input->post('r_year');
                $rmonth = $this->input->post('r_month');
                $rday = $this->input->post('r_day');
                $issuedate = $ryear."-".$rmonth."-".$rday;
               // $issuedate = date('Y-m-d',$issuedate); 
                $eyear = $this->input->post('e_year');
                $emonth = $this->input->post('e_month');
                $eday = $this->input->post('e_day');
                $expiredate = $eyear."-".$emonth."-".$eday;
                //$expiredate = date('Y-m-d',$expiredate); 
                //$date1 = $this->input->post('date');
                
                $date = date('y-m-d h:m:s');
              // die($date);
               
                $source = $this->input->post('income');
                $relation = $this->input->post('relation');
                $title = $this->input->post('title');
                $rtitle = $this->input->post('rtitle');
                $branch = $this->input->post('branch');
                $city = $this->input->post('r_city');
                
                
                $this->dbmodel->addtranzaction($rnumber,$compname,$auth,$sname,$country,$amount,$income,$rname,$raddress,$contact,$identity,$idnumber,$issueplace,$issuedate,$issuedate,$expiredate,$id,$date,$source,$relation,$title,$rtitle,$branch,$city);
                $this->session->set_flashdata('message', 'Tranzaction added sucessfully');
                redirect('view/comfirm');
            }
           
        } else
            {

            redirect('login', 'refresh');
        }
        
    }
            
    
    
    public function addtranzaction_get()
    {
        if ($this->session->userdata('logged_in')) {
                       
            $this->load->library(array('form_validation', 'session'));
            
            $this->form_validation->set_rules('ref_number', 'Refrence Number', 'required|xss_clean|max_length[200]');
           $this->form_validation->set_rules('s_name', 'Sender Name', 'required|xss_clean');
             $this->form_validation->set_rules('s_amount', 'Amount', 'required|xss_clean');
             $this->form_validation->set_rules('r_name', 'Recider Name', 'required|xss_clean');
              $this->form_validation->set_rules('r_add', 'Reciver Address', 'required|xss_clean');
             $this->form_validation->set_rules('r_number', 'Contact Number', 'required|xss_clean');
             $this->form_validation->set_rules('identity', 'Identity', 'required|xss_clean');
             $this->form_validation->set_rules('country', 'Country', 'required|xss_clean');
             $this->form_validation->set_rules('r_idnumber', 'ID Number', 'required|xss_clean');
              $this->form_validation->set_rules('r_issueplace', 'Issue Place', 'required|xss_clean');
            // $this->form_validation->set_rules('r_issuedate', 'Issue Date', 'required|xss_clean');
             $country = $this->input->post('country');
              $data['query']= $this->dbmodel->get_agent();    
        
            if (($this->form_validation->run() == FALSE) ) {
               
                $fcid = $this->input->post('uid');
         $data['customer'] = $this->dbmodel->customer_detail($fcid); 
         $this->load->view('cme/header');
               $this->load->view('cme/get_tran',$data);
               $this->load->view('cme/footer');
              
            }
           else {
 
                //if valid
                $id = $this->input->post('uid');
                $rnumber = $this->input->post('ref_number');
                $compname = $this->input->post('a_name');
                $auth = $this->input->post('auth_code');
                $sname = $this->input->post('s_name');
                $country = $this->input->post('country');
                $amount = $this->input->post('s_amount');
                $income = $this->input->post('income');
                $rname = $this->input->post('r_name');
                $raddress = $this->input->post('r_add');
                $contact = $this->input->post('r_number');
                $identity = $this->input->post('identity');
                $idnumber = $this->input->post('r_idnumber');
                $issueplace = $this->input->post('r_issueplace');
                 $ryear = $this->input->post('r_year');
                $rmonth = $this->input->post('r_month');
                $rday = $this->input->post('r_day');
                $issuedate = $ryear."-".$rmonth."-".$rday;
               // $issuedate = date('Y-m-d',$issuedate); 
                $eyear = $this->input->post('e_year');
                $emonth = $this->input->post('e_month');
                $eday = $this->input->post('e_day');
                $expiredate = $eyear."-".$emonth."-".$eday;
                //$expiredate = date('Y-m-d',$expiredate); 
                //$date = $this->input->post('date');
                $date = date('Y-m-d h:m:s'); 
                $source = $this->input->post('income');
                 $relation = $this->input->post('relation');
                 $title= $this->input->post('title');
                 $rtitle = $this->input->post('rtitle');
                 $branch = $this->input->post('branch');
                 $city = $this->input->post('r_city');
                
                
                $this->dbmodel->addtranzaction($rnumber,$compname,$auth,$sname,$country,$amount,$income,$rname,$raddress,$contact,$identity,$idnumber,$issueplace,$issuedate,$issuedate,$expiredate,$id,$date,$source,$relation,$title,$rtitle,$branch,$city);
                $this->session->set_flashdata('message', 'Tranzaction added sucessfully');
                redirect('view/comfirm');
            }
           
        } else
            {

            redirect('login', 'refresh');
        }
        
    }
    
    public function cuslist()
    {
         if ($this->session->userdata('logged_in') && ($this->session->userdata('username')=="ad")) {
            
             $data['cuslist'] = $this->dbmodel->cuslist();
              $this->load->view('cme/header');  
        $this->load->view('cme/cuslist',$data);
        $this->load->view('cme/footer');
             
         } else {
            redirect('login', 'refresh');
        }
        
    }
}