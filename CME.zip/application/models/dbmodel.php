<?php
class Dbmodel extends CI_Model {

    public function __construct() {
        $this->load->database();
    }

    // This model is to user verified 
    function validate() {
        $this->db->select('role');
        $this->db->where('uname', $this->input->post('username'));
        $this->db->where('upass', md5($this->input->post('password')));
        $query = $this->db->get('user');
        
        

        if ($query->num_rows == 1) {
            return true;
        } else {
            return FALSE;
        }
    }
    
    public function branch(){
         $branch = $this->db->get('branch');
        return $branch->result();
    }

        public function get_branch($id)
    {
         $this->db->select('b_name');
         $this->db->where('id', $id); 
          $branch = $this->db->get('branch');
        return $branch->result();
    }

        public function role()
    {
         $this->db->select('role,u_id,id');
        $this->db->where('uname', $this->input->post('username'));
        $this->db->where('upass', md5($this->input->post('password')));
        $query = $this->db->get('user');
        return $query->result();
        
    }

    // this is another method to get user verified 
    function login($username, $password) {
        $this->db->select('u_id, uname, pass,role');
        $this->db->from('user');
        $this->db->where('uname = ' . "'" . $username . "'");
        $this->db->where('pass = ' . "'" . MD5($password) . "'");
        $this->db->limit(1);
        $query = $this->db->get();
        if ($query->num_rows() == 1) {
            return $query->result();
        } else {
            return false;
        }
    }
    
    public function get_identity($id)
    {
        $this->db->where('c_id ',$id);
        $detail = $this->db->get('identity_detail');
        return $detail->result();
    }

        public function customer()
    {       
        $this->db->order_by('c_id','DESC');
        $query = $this->db->get('customer_info',1);
        return $query->result();
        
    }
    public function get_custmrdetail()
    {
        $query = $this->db->get('customer_info');
        return $query->result();
    }


    public function customer_detail($fcid)
    {
        
         $this->db->where('c_id = '."'".$fcid."'");
        $query = $this->db->get('customer_info');
        return $query->result();
        
    }
    
    public function add_details($cid,$fname, $lname, $address, $distric,$vdc,$tole,$zone,$country,$email,$cusimage,$gender,$dob,$conpersonal,$conhome,$title)
    {
        $data=array(
            'c_id'=>$cid,
            'fname'=>$fname,
            'lname'=>$lname,
            'address'=>$address,
            'distric'=>$distric,
            'vdc'=>$vdc,
            'tole'=>$tole,
            'zone'=>$zone,
            'country'=>$country,
            'email'=>$email,
            'image'=>$cusimage,
                'gender'=>$gender,
            'dob'=>$dob,
            'conpersonal'=>$conpersonal,
            'conhome'=>$conhome,
            'title'=>$title);
        $this->db->insert('customer_info', $data);
        
    }
    
    public function add_id_ctzn($cid,$typectzn,$ctznid,$ctznplace,$ctzndate,$image)
    {
       
        $data=array(            
            'c_id'=>$cid,
            'type'=>$typectzn,
            'id_number'=>$ctznid,
            'issue_place'=>$ctznplace,
            'issue_date'=>$ctzndate,
                'image' =>$image );
         $this->db->insert('identity_detail', $data);
    }
    
    public function add_id_license($cid,$typelicense,$lid,$lplace,$ldate,$image)
    {
         $data=array(
            'c_id'=>$cid,
            'type'=>$typelicense,
            'id_number'=>$lid,
            'issue_place'=>$lplace,
            'issue_date'=>$ldate,
                 'image'=>$image );
          $this->db->insert('identity_detail', $data);
    }
    
    public function add_id_passport($cid,$typepassport,$pid,$pplace,$pdate,$image)
    {
        $data=array(
            'c_id'=>$cid,
            'type'=>$typepassport,
            'id_number'=>$pid,
            'issue_place'=>$pplace,
            'issue_date'=>$pdate,
                'image'=>$image);
        $this->db->insert('identity_detail', $data);
    }
    
    public function add_id_other($cid,$typeother,$oid,$oplace,$odate,$image)
    {
        $data=array(
            'c_id'=>$cid,
            'type'=>$typeother,
            'id_number'=>$oid,
            'issue_place'=>$oplace,
            'issue_date'=>$odate,
                'image'=>$image);
        $this->db->insert('identity_detail', $data);
    }
    
    public function date()
    {
        $this->db->select('issue_date');
        $query = $this->db->get('identity_detail');
        return $query->result();
    }
    
    public function addagent($image,$name,$address,$number,$email,$principal)
    {
        $data = array(
            'image'=>$image,
            'a_name'=>$name,
            'a_address'=>$address,
            'a_number'=>$number,
            'a_email'=>$email,
            'a_principal'=>$principal
        );
         $this->db->insert('cme_agent', $data);
        
    }
    public function get_agentimg($agent)
    {
        $this->db->select('image');
        $this->db->where('a_name',$agent);
         $agentimg = $this->db->get('cme_agent');
         return $agentimg->result();
        
    }

        public function get_agent()
    {
        $query = $this->db->get('cme_agent');
        return $query->result();
    }
    
    public function addtranzaction($rnumber,$compname,$auth,$sname,$country,$amount,$income,$rname,$raddress,$contact,$identity,$idnumber,$issueplace,$issuedate,$issuedate,$expiredate,$id,$date,$source,$relation,$title,$rtitle,$branch,$city)
    {
        
        //die($date);
        $data = array(
            'ref_number'=>$rnumber,
            'agent'=>$compname,
            'auth_code'=>$auth,
            's_name'=>$sname,
            'country'=>$country,
             'amount'=>$amount,
            'u_id'=>$id,
            //'a_name'=>$income,
            'r_name'=>$rname,
            'address'=>$raddress,
            'contact'=>$contact,
             'd_type'=>$identity,
            'd_number'=>$idnumber,
            'date'=>$date,
            'd_place'=>$issueplace,
            'd_date'=>$issuedate,
            'd_expire'=>$expiredate,
            'source'=>$source,
            'relation'=>$relation,
            's_title'=>$title,
            'r_title'=>$rtitle,
            'branch'=>$branch,
            'city' => $city
        );
         $this->db->insert('cme_tranzaction', $data);
        
        
    }
    
    public function get_claim()
    {
         $this->db->order_by('t_id','DESC');
        $query = $this->db->get('cme_tranzaction',1);
        return $query->result();
    }
    
    public function userlist()
    {
        $userlist = $this->db->get('user');
        return $userlist->result();
    }
    
    public function cuslist()
    {
        $cuslist = $this->db->get('customer_info');
        return $cuslist->result();
    }
    
    }